import React, { Suspense } from 'react'
import { Spinner } from "react-bootstrap";
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Layout from '../Layout/Layout';
import Home from '../screens/Home/Home';
import Login from '../screens/Login/Login';
import HealthInsurance from '../screens/HealthInsurance/HealthInsurance';
import VehicleInsurance from '../screens/VehicleInsurance/VehicleInsurance';
import Register from '../screens/Register/Register';
export function SpinnerComponent() {
    return (
        <div className="spinner-wrapper">
            <Spinner animation="grow" variant="info" />
        </div>
    );
}
export default function Router() {
    return (
        <>
            <Suspense fallback={<SpinnerComponent></SpinnerComponent>}>
                <BrowserRouter>
                    <Routes>
                        <Route path="/home" element={<Layout />}>
                            <Route
                                index
                                element={
                                    <Home />
                                }
                            />
                            <Route path='health-insurance' element={<HealthInsurance />} />
                            <Route path='vehicle-insurance' element={<VehicleInsurance />} />

                        </Route>
                        <Route path='/login' element={<Login />} />
                        <Route path='/register' element={<Register />} />

                        <Route path="*" element={<Navigate to={"/login"} replace />} />
                    </Routes>
                </BrowserRouter>
            </Suspense>
        </>
    )
}
