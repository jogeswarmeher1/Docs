import React from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './screens/Login/Login';
import { ErrorBoundary } from 'react-error-boundary';
import Router from './Router/Router';
interface ErrorBoundaryProps {
  error: any;
  resetErrorBoundary: any;
}
function fallbackRender({ error, resetErrorBoundary }: ErrorBoundaryProps) {
  // Call resetErrorBoundary() to reset the error boundary and retry the render.

  return (
    <div role="alert">
      <p>Something went wrong! It's on us...</p>
      <pre style={{ color: "red" }}>{error.message}</pre>
    </div>
  );
}
function App() {
  return (
   <>
   <ErrorBoundary
        fallbackRender={fallbackRender}
        onReset={(details) => {
          // Reset the state of your app so the error doesn't happen again
        }}
      >
        <Router></Router>
      </ErrorBoundary>
   </>
  );
}

export default App;
