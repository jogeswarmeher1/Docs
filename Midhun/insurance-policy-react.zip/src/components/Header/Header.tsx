import React from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom'

export default function Header() {
    const { t, i18n } = useTranslation();
    const changeLanguageHandler = (lang: any) => {
        i18n.changeLanguage(lang);
      };
    const userName = useSelector((state:any) => state.user.userName) 
    return (
        <>
            <Navbar expand="lg" className="bg-info">
                <Container fluid>
                    <Navbar.Brand className="nav-brand-wrapper" href="#home">
                        <Nav.Link className="nav-text"  >

                            <Link className="nav-link ms-2" to={"/home"}>
                            {t('home')}
                            </Link>
                        </Nav.Link>
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="navbarScroll" />
                    <Navbar.Collapse id="navbarScroll">
                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: "100px" }}
                            navbarScroll
                        >
                            <Nav.Link className="nav-text" >
                                <Link className="nav-link ms-2" to={'/home/health-insurance'}>
                                    {t('health_insurance')}
                                </Link>
                            </Nav.Link>
                            <Nav.Link className="nav-text" >
                                <Link className="nav-link ms-2" to={'/home/vehicle-insurance'}>
                                    {t('vehicle_insurance')}
                                </Link>
                            </Nav.Link>
                            <Nav.Link className="nav-text" >
                                <Link className="nav-link ms-2" to={'/logout'}>
                                {t('logout')}
                                </Link>
                            </Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                    <span className='welcomeNote'>{t('welcome')} {userName} </span>
                    <select onChange={(e) => changeLanguageHandler(e.target.value)}>
                        <option value={'en'}>English</option>
                        <option value={'ms'}>Malay</option>
                    </select>
                </Container>
            </Navbar>
        </>
    )
}
