import React from 'react'
import './Footer.css'
export default function Footer() {
  return (
    <div className='footer'>Copyright &#169; {new Date().getFullYear()}</div>
  )
}
