import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { AppDispatch } from '../../store';
import { generatePolicyQuote } from '../../slices/healthPolicyQuoteSlice';
import { addPolicy } from '../../slices/policySlice';
import { Button, Container, Form, Modal, Spinner, Table } from 'react-bootstrap';
import { generateVehiclePolicyQuote } from '../../slices/vehiclePolicyQuoteSlice';

export default function VehicleInsurance() {
    // const [userName, setuserName] = useState('');
    const [age, setAge] = useState('');
    const [vehicleNo, setVno] = useState('');
    const [coverage, setCoverage] = useState('b2b');
    const [show, setShow] = useState(false);
    const [vehType, setVehicleType] = useState('lmv');
    const [ifClaim, setClaimStatus] = useState(false);

    const [spinner, setSpinner] = useState(false);
    const navigate = useNavigate();
    const userName = useSelector((state: any) => state.user.userName)
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const dispatch = useDispatch<AppDispatch>();
    const data = useSelector((state: any) => state.vehiclePolicyQuote.quote)
    // function handleUserName(e: any) {
    //     setuserName(e.target.value)
    // }
    function handleAge(e: any) {
        setAge(e.target.value)
    }
    function handleCoverageAmt(e: any) {
        setCoverage(e.target.value)
    }
    function handleVno(e: any) {
        setVno(e.target.value)

    }
    function handleCoveragePref(value: any) {
        setCoverage(value)
    }
    function handleVehicleType(value: any) {
        setVehicleType(value)
    }
    function handleIfAccidentClaim(e: any) {
        const { name, checked } = e.target
        setClaimStatus(checked);
    }
    const handleSubmit = (e: any) => {
        e.preventDefault();
        const vehicleInsObj = {
            "vehicleNo":vehicleNo,
            "vehicleType":vehType,
            "insuranceType":"Vehicle",
            "driverAge":age,
            "coveragePreference":coverage,
            "ifAccidentClaims":ifClaim,
        }
        dispatch(generateVehiclePolicyQuote(vehicleInsObj))
    }
    const handlePayment = () => {
        const policyObj = {
            "insuranceType": "Vehicle",
            "coverageAmount": data?.coverageAmount,
            "premiumAmount": data?.premiumAmount,
            "termLength": 1,
            "status": "Paid",
            "email": userName
        }
        setSpinner(true);
        dispatch(addPolicy(policyObj)).then((resp: any) => {
            setTimeout(() => {
                setSpinner(false);
                setShow(false);
                navigate("/home")
            }, 5000)
        })


    }
    return (
        <>
            <div className='d-flex align-items-center justify-content-center mt-4'>
                <div className="card w-50">
                    <form>
                        <div className="form-group ">
                            <label htmlFor="vno">Vehicle No</label>
                            <input type="text" className="form-control" id="vno" onChange={handleVno} />
                        </div>
                        <div className="form-group">
                            <label htmlFor="insurancetype">Insurance Type</label>
                            <input type="text" className="form-control" id="insurancetype" placeholder="Vehicle" disabled />
                        </div>
                        <div className="form-group ">
                            <label htmlFor="age">Driver Age</label>
                            <input type="number" className="form-control" id="age" onChange={handleAge} />
                        </div>

                        <div className="form-group  mt-3">
                            <label htmlFor="coverageAmount">Coverage Preference</label>
                            <select className='ms-1' onChange={(e) => handleCoveragePref(e.target.value)}>
                                <option value={'b2b'}>B2B</option>
                                <option value={'3pp'}>Third Party Only</option>
                            </select>
                        </div>
                        <div className="form-group mt-3">
                            <label htmlFor="coverageAmount">Vehicle Type</label>
                            <select className='ms-1' onChange={(e) => handleVehicleType(e.target.value)}>
                                <option value={'lmv'}>LMV</option>
                                <option value={'motorcycle'}>Motorcycle</option>
                            </select>
                        </div>
                        <Form.Check onChange={(e) => handleIfAccidentClaim(e)} // prettier-ignore
                            type="switch"
                            id="custom-switch"
                            label="If Accidental claims?"
                        />
                        <button onClick={(e) => handleSubmit(e)} type="submit" className="btn btn-primary mt-4">Generate Quote</button>
                    </form>
                </div>
            </div>
            {data?.insuranceQuoteId && <Container>
                <Table responsive>
                    <thead>
                        <tr>

                            <th>InsuranceQuoteId</th>
                            <th>Premium Amount</th>
                            <th>Insurance Date</th>
                            <th>Payment Status</th>
                            <th>Coverage Preference</th>
                            <th></th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{data.insuranceQuoteId}</td>
                            <td>{data.premiumAmount}</td>
                            <td>{data.insuranceDate}</td>
                            <td>{data.paymentStatus}</td>
                            <td>{data.coveragePreference.toUpperCase()}</td>
                            <td><Button onClick={handleShow} className='btn btn-info'>Purchase</Button></td>

                        </tr>
                    </tbody>
                </Table>
            </Container>}
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Razor Pay</Modal.Title>
                </Modal.Header>
                <Modal.Body>Transaction Amount : {data.premiumAmount}
                    <br />
                    <label htmlFor='creditcard'>Enter Card Number</label>
                    <input type='text' placeholder='Enter card number' id='creditcard'></input>
                    {spinner && <Spinner className='ms-3' animation="border" role="status">
                        <span className="visually-hidden">Payment in progress...</span>
                    </Spinner>}

                </Modal.Body>

                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Cancel
                    </Button>
                    <Button variant="primary" onClick={handlePayment}>
                        Complete Payment
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}
