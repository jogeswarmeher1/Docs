import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { AppDispatch } from '../../store';
import { generatePolicyQuote } from '../../slices/healthPolicyQuoteSlice';
import { Button, Container, Modal, Spinner, Table } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { addPolicy } from '../../slices/policySlice';

export default function HealthInsurance() {
    // const [userName, setuserName] = useState('');
    const [age, setAge] = useState('');
    const [ssn, setSSN] = useState('');
    const [coverage, setCoverage] = useState('');
    const [show, setShow] = useState(false);
    const [spinner, setSpinner] = useState(false);
    const navigate = useNavigate();
    const userName = useSelector((state:any) => state.user.userName) 
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const dispatch = useDispatch<AppDispatch>();
    const data = useSelector((state: any) => state.policyQuote.quote)
    // function handleUserName(e: any) {
    //     setuserName(e.target.value)
    // }
    function handleAge(e: any) {
        setAge(e.target.value)
    }
    function handleCoverageAmt(e: any) {
        setCoverage(e.target.value)
    }
    function handleSSN(e: any) {
        setSSN(e.target.value)

    }
    const handleSubmit = (e: any) => {
        e.preventDefault();
        const healthInsObj = {
            "userName": userName,
            "insuranceType": "Health",
            "age": age,
            "ssn": ssn,
            "coverageAmount": coverage
        }
        dispatch(generatePolicyQuote(healthInsObj))
    }
    const handlePayment = () => {
        const policyObj = {
            "insuranceType":"Health",
            "coverageAmount": data?.coverageAmount,
            "premiumAmount": data?.premiumAmount,
            "termLength": 1,
            "status": "Paid",
            "email":userName
        }
        setSpinner(true);
        dispatch(addPolicy(policyObj)).then((resp:any) => {
            setTimeout(() => {
                setSpinner(false);
                setShow(false);
                navigate("/home")
            }, 5000)
        })

     
    }
    return (
        <>
            <div className='d-flex align-items-center justify-content-center mt-4'>
                <div className="card w-50">
                    <form>
                        <div className="form-group">
                            <label htmlFor="username">Username</label>
                            <input type="text" className="form-control" id="username" aria-describedby="emailHelp" placeholder="" value={userName}  />
                        </div>
                        <div className="form-group">
                            <label htmlFor="insurancetype">Insurance Type</label>
                            <input type="text" className="form-control" id="insurancetype" placeholder="Health" disabled />
                        </div>
                        <div className="form-group ">
                            <label htmlFor="age">Age</label>
                            <input type="number" className="form-control" id="age" onChange={handleAge} />
                        </div>
                        <div className="form-group ">
                            <label htmlFor="ssn">SSN</label>
                            <input type="text" className="form-control" id="ssn" onChange={handleSSN} />
                        </div>
                        <div className="form-group ">
                            <label htmlFor="coverageAmount">Coverage Amount</label>
                            <input type="text" className="form-control" id="coverageAmount" onChange={handleCoverageAmt} />
                        </div>

                        <button onClick={(e) => handleSubmit(e)} type="submit" className="btn btn-primary mt-4">Generate Quote</button>
                    </form>
                </div>
            </div>
            {data?.insuranceQuoteId && <Container>
                <Table responsive>
                    <thead>
                        <tr>

                            <th>InsuranceQuoteId</th>
                            <th>Premium Amount</th>
                            <th>Insurance Date</th>
                            <th>Payment Status</th>
                            <th>Coverage Amount</th>
                            <th></th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{data.insuranceQuoteId}</td>
                            <td>{data.premiumAmount}</td>
                            <td>{data.insuranceDate}</td>
                            <td>{data.paymentStatus}</td>
                            <td>{data.coverageAmount}</td>
                            <td><Button onClick={handleShow} className='btn btn-info'>Purchase</Button></td>

                        </tr>
                    </tbody>
                </Table>
            </Container>}
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Razor Pay</Modal.Title>
                </Modal.Header>
                <Modal.Body>Transaction Amount : {data.premiumAmount}
                    <br />
                    <label htmlFor='creditcard'>Enter Card Number</label>
                    <input type='text' placeholder='Enter card number' id='creditcard'></input>
                    {spinner && <Spinner className='ms-3' animation="border" role="status">
                        <span className="visually-hidden">Payment in progress...</span>
                    </Spinner>}

                </Modal.Body>

                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Cancel
                    </Button>
                    <Button variant="primary" onClick={handlePayment}>
                        Complete Payment
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}
