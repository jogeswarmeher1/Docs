import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { AppDispatch } from '../../store';
import { createUser } from '../../slices/userSlice';
import { useNavigate } from 'react-router-dom';
import { Button, Modal } from 'react-bootstrap';

export default function Register() {
  const navigate = useNavigate();

    const [email,setEmail] = useState("");
    const [username,setUsername] = useState("");
    const [pwd1,setPwd1] = useState("");
    const [pwd2,setPwd2] = useState("")
    const [show, setShow] = useState(false);

  const handleClose = () => {

    setShow(false);
                navigate('/login')

  } 
    const dispatch = useDispatch<AppDispatch>();

    function handleUsername(e:any) {
        setUsername(e.target.value);
    }
    function handleEmail(e:any) {
        setEmail(e.target.value)
    }
    function handlePwd1(e:any) {
        setPwd1(e.target.value)
    }
    function handlePwd2(e:any) {
        setPwd2(e.target.value)
    }
    const handleSubmit = (e: any) => {
        e.preventDefault();
        if(pwd1 !== pwd2) {
            alert('Passwords does not match!!!')
        }
        else {
            const userObj = {
                "userName":username,
                "password":pwd1,
                "email":email
            }
            dispatch(createUser(userObj)).then((resp:any) => {
                setShow(true);
            })
        }
    }
  return (
    <div className='d-flex align-items-center justify-content-center mt-4'>
      <div className="card w-50">
        <form>
        <div className="form-group">
            <label htmlFor="username">Email address</label>
            <input type="text" className="form-control" id="username" aria-describedby="emailHelp" placeholder="Enter Username" onChange={handleUsername} />
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputEmail1">Email address</label>
            <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" onChange={handleEmail} />
            <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputPassword1">Password</label>
            <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" onChange={handlePwd1} />
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputPassword1">Confirm Password</label>
            <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" onChange={handlePwd2} />
          </div>
         
          <button onClick={(e) => handleSubmit(e)} type="submit" className="btn btn-primary mt-4">Submit</button>
        </form>
      </div>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>User Registered!!</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo,you are succesfully registered! Login to continue</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
    
  )
}
