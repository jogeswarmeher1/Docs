const TableHeaderConstants = [
    "Insurance Id",
    "Insurance Type",
    "Coverage Amount",
    "Premium Amount",
    "TermLength",
    "Insurance Date",
    "Status",
    "Actions"
]
export default TableHeaderConstants;