import React, { useEffect, useState } from 'react'
import { Button, Container, Table } from 'react-bootstrap'
import TableHeaderConstants from './TableHeaderConstant'
import { useDispatch, useSelector } from 'react-redux'
import { AppDispatch } from '../../store'
import { deletePolicy, getAllPolicy } from '../../slices/policySlice'

export default function Home() {
    const userName = useSelector((state: any) => state.user.userName)
    const data = useSelector((state: any) => state.policy.data)
    const dispatch = useDispatch<AppDispatch>();
    useEffect(() => {
        dispatch(getAllPolicy(userName));
    }, [])
    const handleDelete = (insuranceId: any) => {
        if (window.confirm('Are you sure you want to delete this policy?')) {
            dispatch(deletePolicy(insuranceId));
        }
    }
    return (
        <>
            <h3 className='text-center'>Your Policies</h3>
            <Container>
                <Table responsive>
                    <thead>
                        <tr>
                            <th>#</th>
                            {TableHeaderConstants.map((header: string, index: any) => (
                                <th key={index}>{header}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {data?.map((data: any, index: any) => (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{data.insuranceId}</td>
                                <td>{data.insuranceType}</td>
                                <td>{data.coverageAmount}</td>
                                <td>{data.premiumAmount}</td>
                                <td>{data.termLength}</td>
                                <td>{data.insuranceDate}</td>
                                <td>{data.status}</td>
                                <td><Button onClick={() => handleDelete(data.insuranceId)} className='btn btn-danger'>Delete</Button></td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </Container>
        </>
    )
}
