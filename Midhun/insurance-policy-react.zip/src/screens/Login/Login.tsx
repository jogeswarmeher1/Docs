import React from 'react'
import { useState } from 'react';
import './Login.css';
import { useDispatch } from 'react-redux';
import { authenticateUser } from '../../slices/userSlice';
import { AppDispatch } from '../../store';
import { Link, useNavigate } from 'react-router-dom';
const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  function handleEmail(e: any) {
    setEmail(e.target.value);
  }
  function handlePwd(e: any) {
    setPassword(e.target.value);
  }

  const handleSubmit = (e: any) => {
    e.preventDefault();
    const userObj = {
      userName: email,
      password: password
    }
    dispatch(authenticateUser(userObj))
      .then((resp) => {
        if (resp) {
          navigate("/home")
        }
      });
  };
  return (
    <div className='d-flex align-items-center justify-content-center flex-direction-column mt-4'>
        <h2>Insurance Policy Systems</h2>
      <div className="card w-50">
        <form>
          <div className="form-group">
            <label htmlFor="exampleInputEmail1">Email address</label>
            <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" onChange={handleEmail} />
            <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputPassword1">Password</label>
            <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" onChange={handlePwd} />
          </div>

          <button onClick={(e) => handleSubmit(e)} type="submit" className="btn btn-primary mt-2">Submit</button>
        </form>
        <span>Not registered? <Link to={'/register'}>Click here</Link> </span>
      </div>
    </div>
  )
}

export default Login