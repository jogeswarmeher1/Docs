import React from 'react'
import { Container } from 'react-bootstrap'
import Header from '../components/Header/Header'
import { Outlet } from 'react-router-dom'
import Footer from '../components/Footer/Footer'

export default function Layout() {
  return (
 <>
  <Container fluid className="px-0">
        <Header />
        <Outlet />
        <Footer />
    </Container>
 </>
  )
}
