import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slices/userSlice'
import persistedUserReducer from './slices/userSlice';
import policyReducer from './slices/policySlice';
import policyQuoteReducer from './slices/healthPolicyQuoteSlice'
import vehiclePolicyQuoteReducer from './slices/vehiclePolicyQuoteSlice'
import { persistStore } from 'redux-persist';
const store = configureStore({
    reducer: {
      user: persistedUserReducer,
      policy: policyReducer,
      policyQuote: policyQuoteReducer,
      vehiclePolicyQuote: vehiclePolicyQuoteReducer
    },
  });
const persistor = persistStore(store)
export type AppDispatch = typeof store.dispatch;
export  {store,persistor};