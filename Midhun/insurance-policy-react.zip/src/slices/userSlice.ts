import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { persistReducer } from 'redux-persist';
import storage from "redux-persist/lib/storage";
interface UserState {
    userName: any;
    password: any;
    authenticated: boolean
    error: string | null;
}
const initialState: UserState = {
    userName: null,
    password: null,
    authenticated: false,
    error:  null
};
export const authenticateUser = createAsyncThunk(
    'user/login', async (userObj:any) => {
        const {userName,password} = userObj;
    const response = await axios.post(
      `http://localhost:8080/api/user/login`,
      {
        email:userName,
        password:password
      });
    return response.data;
});
export const createUser =  createAsyncThunk(
    'user/register', async (userObj:any) => {
        const response = await axios.post(
            `http://localhost:8080/api/user`,
            {
                ...userObj
            }
        )
        return userObj.email;
    }
)
const userSlice = createSlice({
    name: 'login',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(authenticateUser.pending, (state) => {
            state.authenticated = false;
            state.error = null;
        })
        .addCase(authenticateUser.fulfilled, (state,action) => {
            
                state.authenticated = true;
                state.userName = action.payload
            
        })
        .addCase(authenticateUser.rejected, (state,action) => {
            state.authenticated = false;
            state.error = action.error.message || 'An error occurred';
        })
        .addCase(createUser.pending, (state) => {
            
        })
        .addCase(createUser.fulfilled, (state:any,action:any) => {
            state.userName = action.payload
        })
    }
})
const userSlicePersistConfig = {
    key:'user',
    storage: storage
}
const persistedUserReducer = persistReducer(
    userSlicePersistConfig,
    userSlice.reducer
)
export default persistedUserReducer;