import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

interface VehiclePolicyQuoteState {
    quote: {
        "insuranceQuoteId": string,
        "premiumAmount": number,
        "insuranceDate":string,
        "paymentStatus": string,
        "vehicleNo": string,
        "vehicleType": string,
        "driverAge": number,
        "coveragePreference": string,
        "ifAccidentClaims": boolean
    }
}
const initialState: VehiclePolicyQuoteState = {
   quote: {
    "insuranceQuoteId": "",
    "premiumAmount": 0,
    "insuranceDate": "",
    "paymentStatus": "",
    "vehicleNo": "",
    "vehicleType": "",
    "driverAge": 0,
    "coveragePreference": "",
    "ifAccidentClaims": false
}
}
export const generateVehiclePolicyQuote = createAsyncThunk(
    'user/allVehiclePolicyQuote', async (quoteObj:any) => {
        const response = await axios.post(
            `http://localhost:8080/api/quote/vehicle`,
            {
                ...quoteObj
            }
           );
    return response.data;
})
const vehiclePolicyQuote = createSlice({
    name:'vehiclePolicyQuote',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(generateVehiclePolicyQuote.pending, (state:any) => {
            
        })
        .addCase(generateVehiclePolicyQuote.fulfilled, (state:any, action:any) => {
            state.quote = action.payload
        })
        .addCase(generateVehiclePolicyQuote.rejected, (state:any,action) => {
            state.quote = []
        })
    }

})
export default vehiclePolicyQuote.reducer;