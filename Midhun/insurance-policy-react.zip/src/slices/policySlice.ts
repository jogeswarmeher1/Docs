import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

interface PolicyState {
    "insuranceId" : String,
    "insuranceType": String,
    "coverageAmount": String,
    "premiumAmount": String,
    "termLength": Number,
    "status": String,
    "insuranceDate": String,
    "email": String
}
interface AllPolicyState {
    data : PolicyState[]
}
const initialState: AllPolicyState = {
    data : [{
        "insuranceId" : "",
        "insuranceType": "",
        "coverageAmount": "",
        "premiumAmount": "",
        "termLength": 0,
        "status": "",
        "insuranceDate": "",
        "email": ""
    }]
};
export const getAllPolicy = createAsyncThunk(
    'user/allPolicy', async (userEmail:any) => {
        const response = await axios.get(
            `http://localhost:8080/api/policy?email=${userEmail}`
           );
    return response.data;
})
export const deletePolicy = createAsyncThunk(
    'user/deletePolicy', async (insuranceId:any,thunkApi) => {
        const response = await axios.delete(
            `http://localhost:8080/api/policy?insuranceId=${insuranceId}`
        )
        return insuranceId;
    }
)
export const addPolicy = createAsyncThunk(
    'user/addPolicy' , async(policyObj:any) => {
        const response = await axios.post(
            `http://localhost:8080/api/policy`,
            {
                ...policyObj
            }
        )
        return response.data
    }
)
const policySlice = createSlice({
    name: 'policy',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(getAllPolicy.pending, (state:any) => {
            state.data =  []
        })
        .addCase(getAllPolicy.fulfilled, (state,action) => {
            state.data = action.payload;
        })
        .addCase(getAllPolicy.rejected, (state:any,action) => {
            state.data = []
        })
        .addCase(deletePolicy.fulfilled, (state:any,action) => {
           state.data =state.data.filter((item:any) => item.insuranceId !== action.payload)
        })
        .addCase(addPolicy.pending, (state) => {

        })
        .addCase(addPolicy.fulfilled,(state:any,action:any) => {
            state.data.push(action.payload);
        })
        .addCase(addPolicy.rejected, (stateLany,action:any) => {
        })
    }
})
export default policySlice.reducer;