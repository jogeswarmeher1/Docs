import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

interface PolicyQuoteState {
    quote: {
        "insuranceQuoteId":String
        "premiumAmount": Number,
        "insuranceDate": String,
        "paymentStatus": String,
        "userName": String,
        "age": Number,
        "ssn": String,
        "coverageAmount":Number
    }
}
const initialState: PolicyQuoteState = {
   quote: {
     "insuranceQuoteId": "",
    "premiumAmount": 0.0,
    "insuranceDate": "",
    "paymentStatus": "",
    "userName": "",
    "age": 0,
    "ssn": "",
    "coverageAmount": 0.0
}
}
export const generatePolicyQuote = createAsyncThunk(
    'user/allPolicyQuote', async (quoteObj:any) => {
        const response = await axios.post(
            `http://localhost:8080/api/quote/life`,
            {
                ...quoteObj
            }
           );
    return response.data;
})
const policyQuote = createSlice({
    name:'policyQuote',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(generatePolicyQuote.pending, (state:any) => {
            
        })
        .addCase(generatePolicyQuote.fulfilled, (state:any, action:any) => {
            state.quote = action.payload
        })
        .addCase(generatePolicyQuote.rejected, (state:any,action) => {
            state.quote = []
        })
    }

})
export default policyQuote.reducer;