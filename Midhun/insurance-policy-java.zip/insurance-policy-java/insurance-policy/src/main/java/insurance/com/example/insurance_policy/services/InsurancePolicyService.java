package insurance.com.example.insurance_policy.services;


import insurance.com.example.insurance_policy.entity.InsurancePolicy;
import insurance.com.example.insurance_policy.repository.InsurancePolicyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Random;

@Service
public class InsurancePolicyService {

    @Autowired
    private InsurancePolicyRepository insurancePolicyRepository;

    public List<InsurancePolicy> findAllPolicy() {
        return insurancePolicyRepository.findAll();
    }
    public List<InsurancePolicy> findPolicyById(String id) {
        return insurancePolicyRepository.findInsurancePolicyById(id);
    }
    public List<InsurancePolicy> findPolicyByEmail(String email) {
        return insurancePolicyRepository.findInsurancePolicyByEmail(email);
    }
    public String generateUniquePolicyId() {
        long timestamp = System.currentTimeMillis();
        Random random =  new Random();
        int randomInt =  random.nextInt(10000);
        return "POLICY-" + timestamp+"-"+randomInt;
    }
    public InsurancePolicy addInsurancePolicy(InsurancePolicy addInsurancePolicy) {
        InsurancePolicy insurancePolicyDto = new InsurancePolicy();
        insurancePolicyDto.setInsuranceId(this.generateUniquePolicyId());
        insurancePolicyDto.setInsuranceType(addInsurancePolicy.getInsuranceType());
        insurancePolicyDto.setCoverageAmount(addInsurancePolicy.getCoverageAmount());
        insurancePolicyDto.setPremiumAmount(addInsurancePolicy.getPremiumAmount());
        insurancePolicyDto.setTermLength(addInsurancePolicy.getTermLength());
        insurancePolicyDto.setStatus(addInsurancePolicy.getStatus());
        insurancePolicyDto.setInsuranceDate(LocalDate.now());
        insurancePolicyDto.setEmail(addInsurancePolicy.getEmail());
        return insurancePolicyRepository.save(insurancePolicyDto);
    }
    public void updateInsuranceById(InsurancePolicy insurancePolicy) {
        String insuranceId = String.valueOf(insurancePolicy.getInsuranceId());
        List<InsurancePolicy> insurancePolicy1 = insurancePolicyRepository.findInsurancePolicyById(insuranceId);
        if(!insurancePolicy1.isEmpty()) {
            InsurancePolicy insurancePolicy2 = new InsurancePolicy();
            insurancePolicy2.setInsuranceType(insurancePolicy.getInsuranceType());
            insurancePolicy2.setCoverageAmount(insurancePolicy.getCoverageAmount());
            insurancePolicy2.setPremiumAmount(insurancePolicy.getPremiumAmount());
            insurancePolicy2.setTermLength(insurancePolicy.getTermLength());
            insurancePolicy2.setStatus(insurancePolicy.getStatus());
            insurancePolicyRepository.updatePolicy(insuranceId,insurancePolicy2);
        }
    }
    public void deletePolicyById(String policyId) {
        List<InsurancePolicy> insurancePolicy = insurancePolicyRepository.findInsurancePolicyById(policyId);

        insurancePolicyRepository.deletePolicy(insurancePolicy.get(0).getInsuranceId());
    }
}
