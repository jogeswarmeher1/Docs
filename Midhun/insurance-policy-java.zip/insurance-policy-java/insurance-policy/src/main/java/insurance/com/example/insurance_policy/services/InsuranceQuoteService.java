package insurance.com.example.insurance_policy.services;

import insurance.com.example.insurance_policy.entity.LifeInsurance;
import insurance.com.example.insurance_policy.entity.VehicleInsurance;
import insurance.com.example.insurance_policy.repository.InsuranceQuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Random;

@Service
public class InsuranceQuoteService {

    @Autowired
    InsuranceQuoteRepository insuranceQuoteRepository;

    private String generateUniqueQuoteId() {
        long timestamp = System.currentTimeMillis();
        Random random =  new Random();
        int randomInt =  random.nextInt(10000);
        return "QUOTE-" + timestamp+"-"+randomInt;
    }
    private Double calculateHealthPremium(int age,Double coverageAmount) {
        double baseRate = 0.05;
        if(age< 30) {
            baseRate +=0.01;
        } else if (age<50) {
            baseRate += 0.02;
        } else {
            baseRate += 0.03;
        }
        return (double) Math.round(coverageAmount * baseRate);
    }
    public LifeInsurance generateHealthInsuranceQuote(LifeInsurance lifeInsurance) {

        LifeInsurance lifeInsuranceDto =  new LifeInsurance(lifeInsurance.getUserName(),lifeInsurance.getAge(), lifeInsurance.getSsn(), lifeInsurance.getCoverageAmount());
        lifeInsuranceDto.setCoverageAmount(lifeInsurance.getCoverageAmount());
        lifeInsuranceDto.setInsuranceQuoteId(generateUniqueQuoteId());
        lifeInsuranceDto.setInsuranceDate(LocalDate.now());
        lifeInsuranceDto.setPremiumAmount(calculateHealthPremium(lifeInsurance.getAge(),lifeInsurance.getCoverageAmount()));
        lifeInsuranceDto.setPaymentStatus("Pending");
        insuranceQuoteRepository.save(lifeInsuranceDto);
        return lifeInsuranceDto;
    }
    private Double calculateVehiclePremium(int driverAge, String vehicleType,Boolean ifAccidentClaims) {
        double basePremium = 1000;
        double premium = basePremium;
        if(driverAge < 25) {
            premium += basePremium * 0.20;
        } else if(driverAge > 60) {
            premium += basePremium * 0.15;
        }
        if(vehicleType.equals("motorcycle")) {
            premium += basePremium * 0.20;
        } else if(vehicleType.equalsIgnoreCase("lmv")) {
            premium += basePremium * 0.50;
        } else {
            premium += basePremium * 0.70;
        }
        if(ifAccidentClaims) {
            premium += basePremium * 0.25;
        }
        return premium;
    }
    public VehicleInsurance generateVehicleInsuranceQuote(VehicleInsurance vehicleInsurance) {

        VehicleInsurance vehicleInsuranceDto =  new VehicleInsurance(vehicleInsurance.getVehicleNo(), vehicleInsurance.getVehicleType(), vehicleInsurance.getDriverAge(),vehicleInsurance.getCoveragePreference(),vehicleInsurance.getIfAccidentClaims());
        vehicleInsuranceDto.setInsuranceQuoteId(generateUniqueQuoteId());
        vehicleInsuranceDto.setInsuranceDate(LocalDate.now());
        vehicleInsuranceDto.setPremiumAmount(calculateVehiclePremium(vehicleInsurance.getDriverAge(),vehicleInsurance.getVehicleType(),vehicleInsurance.getIfAccidentClaims()));
        vehicleInsuranceDto.setPaymentStatus("Pending");
        insuranceQuoteRepository.save(vehicleInsuranceDto);
        return vehicleInsuranceDto;
    }
}
