package insurance.com.example.insurance_policy.repository;

import insurance.com.example.insurance_policy.entity.InsurancePolicy;
import insurance.com.example.insurance_policy.entity.InsuranceQuote;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;

public interface InsuranceQuoteRepository extends MongoRepository<InsuranceQuote,String> {
    @Query("{insuranceQuoteId:'?0'}")
    @Update("{'$set': ?1}")
    void updatePolicy(String id, InsurancePolicy insurancePolicy);
}
