package insurance.com.example.insurance_policy.entity;

import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Document(collection = "User")
public class User {

    @NonNull
    String userName;
    @NonNull
    String email;
    String password;
}
