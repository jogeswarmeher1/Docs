package insurance.com.example.insurance_policy.controller;

import insurance.com.example.insurance_policy.entity.User;
import insurance.com.example.insurance_policy.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        String resp = userService.registerUser(user);
        return ResponseEntity.status(200).body(resp);
    }
    @PostMapping(value = "/login", consumes = "application/json")
    public ResponseEntity<String> loginUser(@RequestBody User user) {
        String resp = userService.loginUser(user);
        if(resp.equalsIgnoreCase("Unauthorized")) {
            return ResponseEntity.status(401).body(resp);
        }
        else {
            return ResponseEntity.status(200).body(resp);

        }
    }
}
