package insurance.com.example.insurance_policy.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "InsuranceQuotes")
public class InsuranceQuote {
    String insuranceQuoteId;
    Double premiumAmount;
    LocalDate insuranceDate;
    String paymentStatus;
}
