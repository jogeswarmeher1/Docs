package insurance.com.example.insurance_policy.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@AllArgsConstructor
public class VehicleInsurance extends InsuranceQuote{

    String vehicleNo;
    String vehicleType;
    int driverAge;
    String coveragePreference;
    Boolean ifAccidentClaims;
    VehicleInsurance() {
        super();
    }
}
