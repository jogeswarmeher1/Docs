package insurance.com.example.insurance_policy.controller;


import insurance.com.example.insurance_policy.entity.InsurancePolicy;
import insurance.com.example.insurance_policy.services.InsurancePolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/policy")
@CrossOrigin(origins = "http://localhost:3000")
public class InsurancePolicyController {

    @Autowired
    InsurancePolicyService insurancePolicyService;


    @GetMapping()
    public List<InsurancePolicy> findInsurancePolicyById(
            @RequestParam(required = false,defaultValue = "") String insuranceId,
            @RequestParam(required = false,defaultValue = "") String email) {
        if(!insuranceId.isEmpty()) {
           return insurancePolicyService.findPolicyById(insuranceId);

        } else if (!email.isEmpty()) {
            return insurancePolicyService.findPolicyByEmail(email);
        }
        return insurancePolicyService.findAllPolicy();
    }
    @PostMapping(consumes = "application/json")
    public ResponseEntity<InsurancePolicy> addInsurancePolicy(@RequestBody InsurancePolicy insurancePolicy) {
        InsurancePolicy insurancePolicy1 =  insurancePolicyService.addInsurancePolicy(insurancePolicy);
        return ResponseEntity.status(200).body(insurancePolicy1);
    }

    @PutMapping(consumes = "application/json")
    public void updateInsurancePolicy(@RequestBody InsurancePolicy insurancePolicy) {
        insurancePolicyService.updateInsuranceById(insurancePolicy);
    }
    @DeleteMapping
    public void deletePolicy(@RequestParam String insuranceId) {
        insurancePolicyService.deletePolicyById(insuranceId);
    }
}
