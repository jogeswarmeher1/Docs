package insurance.com.example.insurance_policy.repository;

import insurance.com.example.insurance_policy.entity.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface UserRepository extends MongoRepository<User,String> {

    @Query("{'email' : ?0, 'password':?1}")
    public List<User> findUserByEmail(String email,String password);
}
