package insurance.com.example.insurance_policy.controller;

import insurance.com.example.insurance_policy.entity.LifeInsurance;
import insurance.com.example.insurance_policy.entity.VehicleInsurance;
import insurance.com.example.insurance_policy.services.InsuranceQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/quote")
@CrossOrigin(origins = "http://localhost:3000")
public class InsuranceQuoteController {

    @Autowired
    InsuranceQuoteService insuranceQuoteService;

    @PostMapping(value = "/life")
    public ResponseEntity<LifeInsurance> generateHealthInsuranceQuote(@RequestBody LifeInsurance lifeInsurance) {
        LifeInsurance lifeInsurance1= insuranceQuoteService.generateHealthInsuranceQuote(lifeInsurance);
        return ResponseEntity.status(200).body(lifeInsurance1);
    }
    @PostMapping(value = "/vehicle")
    public ResponseEntity<VehicleInsurance> geneVehicleInsuranceQuote(@RequestBody VehicleInsurance vehicleInsurance) {
        VehicleInsurance vehicleInsurance1 =  insuranceQuoteService.generateVehicleInsuranceQuote(vehicleInsurance);
        return ResponseEntity.status(200).body(vehicleInsurance1);
    }
}
