package insurance.com.example.insurance_policy.services;

import insurance.com.example.insurance_policy.entity.User;
import insurance.com.example.insurance_policy.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;
    public String registerUser(User user) {
        User userDto = new User();
        userDto.setUserName(user.getUserName());
        userDto.setPassword(user.getPassword());
        userDto.setEmail(user.getEmail());
        userRepository.save(userDto);
        return "User registered";
    }
    public String loginUser(User user) {
        List<User> resp = userRepository.findUserByEmail(user.getEmail(),user.getPassword());
        if(!resp.isEmpty()) {
            return user.getEmail();
        }
        else {
            return "Unauthorized";
        }
    }

}
