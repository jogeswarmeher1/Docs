package insurance.com.example.insurance_policy.repository;

import insurance.com.example.insurance_policy.entity.InsurancePolicy;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;

import java.util.List;

public interface InsurancePolicyRepository extends MongoRepository<InsurancePolicy,String> {
    @Query("{insuranceId :'?0'}")
    List<InsurancePolicy> findInsurancePolicyById(String insuranceId);

    @Query("{email :'?0'}")
    List<InsurancePolicy> findInsurancePolicyByEmail(String email);

    @Query("{insuranceId:'?0'}")
    @Update("{'$set': ?1}")
    void updatePolicy(String id,InsurancePolicy insurancePolicy);

    @DeleteQuery("{insuranceId : '?0'}")
    void deletePolicy(String insuranceId);

}
