package insurance.com.example.insurance_policy.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@AllArgsConstructor
public class LifeInsurance extends InsuranceQuote{
    String userName;
    Integer age;
    String ssn;
    Double coverageAmount;

   LifeInsurance() {
        super();
    }
}
