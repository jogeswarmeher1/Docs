package insurance.com.example.insurance_policy.entity;

import jakarta.persistence.Id;
import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

import java.time.LocalDate;

@AllArgsConstructor
@Data
@NoArgsConstructor
@Document(collection = "InsurancePolicy")
public class InsurancePolicy {

    @Id
    String insuranceId;
    @NonNull
    String insuranceType;
    String coverageAmount;
    @NonNull
    Float premiumAmount;
    @NonNull
    Integer termLength;
    @NonNull
    String status;
    @NonNull
    LocalDate insuranceDate;
    //unique id
    @NonNull
    String email;
}
