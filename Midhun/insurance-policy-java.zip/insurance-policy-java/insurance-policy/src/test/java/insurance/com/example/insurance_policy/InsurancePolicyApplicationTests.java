package insurance.com.example.insurance_policy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsurancePolicyApplicationTests {

	@Test
	void contextLoads() {
	}

}
