package steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utils.ShadowDomUtils;

public class BeforeActions {

	public static WebDriver driver;
	public static WebDriverWait wait;
	String currentPrice;
	String productname;
	ShadowDomUtils shadowDom = new ShadowDomUtils(driver);
	

	@Before
	public static void setUp() {
		// ExtentCucumberFormatter.initiateExtentCucumberFormatter();
		System.out.println("Execution Started");
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\2146883\\eclipse-workspace\\bolttech\\DriverFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		wait= new WebDriverWait(driver, 10);
	}

	@Given("I open the browser and navigate to {string} page")
	public void i_open_the_browser_and_navigate_to_page(String string) throws InterruptedException {
		if (string.contains("#")) {
			driver.get(
					"https://www.bolttech.co.th/en/fwd/car-insurance/ctpl-insurance?utm_source=fwd&utm_medium=genesis");
			
			Thread.sleep(10000);
			WebElement AcceptCookies = driver.findElement(By.xpath("//button[@id='onetrust-accept-btn-handler']"));
			if (AcceptCookies.isDisplayed()) {
				AcceptCookies.click();
			}
		}
	}

	
	@Then("I compare the values from the table")
	public void i_compare_the_values_from_the_table() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String pricePath=".shadowRoot.querySelector(\"#card > edi-card-vertical-content\").shadowRoot.querySelector(\"div > div.price-container > h3 > edi-counter\").shadowRoot.querySelector(\"#counter\")";
		
		WebElement prc1=(WebElement) js.executeScript("return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child(1)\")"+pricePath);
		WebElement prc2=(WebElement) js.executeScript("return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child(2)\")"+pricePath);
		Long rows= (Long) js.executeScript("return document.querySelector(\"#coverages > edi-plan-compare\").shadowRoot.querySelector(\"div > div > div:nth-child(4)\").length");
		for (int i = 0; i < rows; i++) {
			WebElement wb = (WebElement) js.executeScript(
					"return document.querySelector(\"#coverages > edi-plan-compare\").shadowRoot.querySelectorAll(\"div > div > div:nth-child(4)>div>div\")["+i+"]");
			
		}
	}

	@When("I select a {string} plan")
	public void i_select_a_plan(String planType) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String productNamePath=".shadowRoot.querySelector(\"#card > edi-card-vertical-content\").shadowRoot.querySelector(\"div > header > div.edi-card-vertical__title.header-with-partner > p\")";
		String pricePath=".shadowRoot.querySelector(\"#card > edi-card-vertical-content\").shadowRoot.querySelector(\"div > div.price-container > h3 > edi-counter\").shadowRoot.querySelector(\"#counter\")";
		HashMap<WebElement, Integer> hm = new LinkedHashMap<WebElement, Integer>();
		int cards = 0;
		for (int i = 1; i < 5; i++) {
			WebElement wb = (WebElement) js.executeScript(
					"return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child(" + i + ")\")");
			if (wb != null) {
				cards++;
			} else {
				break;
			}

		}
		System.out.println(cards);
		for (int i = 1; i <= cards; i++) {
			WebElement wb = (WebElement) js
					.executeScript("return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child(" + i
							+ ")\").shadowRoot.querySelector(\"#card > edi-card-vertical-content\").shadowRoot.querySelector(\"div > header > div.edi-card-vertical__title.header-with-partner > p\")");
			hm.put(wb, i);
		}

		if (planType.equalsIgnoreCase("random")) {
			Random random = new Random();
			int index= random.nextInt(cards)+1;
			WebElement wb = (WebElement) js.executeScript(
					"return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child("+index+")\").shadowRoot.querySelector(\"#card > edi-card-vertical-content\").shadowRoot.querySelector(\"div > edi-cta\").shadowRoot.querySelector(\"div > a > span > span\")");
			WebElement prd=(WebElement) js.executeScript("return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child("+index+")\")"+productNamePath);
			WebElement prc=(WebElement) js.executeScript("return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child("+index+")\")"+pricePath);
			productname= prd.getText();
			currentPrice=prc.getText();
			Thread.sleep(5000);
			wb.click();
			System.out.println(productname+" Select Button Is Clicked Success");

		} else {
			for (Map.Entry<WebElement, Integer> webElement : hm.entrySet()) {
				if (webElement.getKey().getText().equalsIgnoreCase(planType)) {
					WebElement wb = (WebElement) js.executeScript(
							"return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child("+webElement.getValue()+")\").shadowRoot.querySelector(\"#card > edi-card-vertical-content\").shadowRoot.querySelector(\"div > edi-cta\").shadowRoot.querySelector(\"div > a > span > span\")");

					WebElement prd=(WebElement) js.executeScript("return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child("+webElement.getValue()+")\")"+productNamePath);
					WebElement prc=(WebElement) js.executeScript("return document.querySelector(\"edi-card-slider > edi-card-vertical:nth-child("+webElement.getValue()+")\")"+pricePath);
					productname= prd.getText();
					currentPrice=prc.getText();
					Thread.sleep(5000);
					wb.click();
					System.out.println(productname+" Select Button Is Clicked Success");
				}
			}

		}


	}

	@Then("I validate the URL contains {string}")
	public void i_validate_the_url_contains(String urlValue) {
		wait.until(ExpectedConditions.urlContains(urlValue));
		String currentUrl= driver.getCurrentUrl();
		Assert.assertTrue("Checkout URL Validation failed", currentUrl.contains(urlValue));
	}
	
	@Given("I validate informative fields on checkOut page")
	public void i_validate_informative_fields_on_check_out_page() {
	    String jspath= "document.querySelector(\"edi-checkout\").shadowRoot.querySelector(\"div > div.col-md-4.no-padding-md.sum-col > div > edi-product-summary\")";
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    
	    WebElement plan=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#productSummary > div > edi-loading > div.panel-content.summary-title > p\")");
	    WebElement price=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#productSummary > div > edi-loading > div.panel-content.summary-title > div > div > p\")");
	    WebElement provider=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#providerName\")");
	    WebElement coverageStart=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#coverageStart\")");
	    WebElement coverageEnd=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#coverageEnd\")");
	    
	    Assert.assertEquals("Plan name mismatch", productname, plan.getText());
	    Assert.assertEquals("Price value mismatch", currentPrice, price.getText());
	    Assert.assertEquals("Provider name mismatch", "ERGO", provider.getText());
	    Assert.assertEquals("Coverage start date mismatch", "Sun, 27 Oct 2024", coverageStart.getText());
	    Assert.assertEquals("Coverage period mismatch", "12 months", coverageEnd.getText());
	}
	
	@Given("I change the policy startDate to maximum allowed on date picker")
	public void i_change_the_policy_start_date_to_maximum_allowed_on_date_picker() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String jspath="document.querySelector(\"edi-checkout\").shadowRoot.querySelector(\"div:nth-child(1) > edi-user-details\")";
		String calPath="document.querySelector(\"edi-checkout\").shadowRoot.querySelector(\"div > div.col-12.col-md-8.form-col > div:nth-child(1) > edi-user-details\").shadowRoot.querySelector(\"#coverageStartDatepicker\").shadowRoot.querySelector(\"#datePicker\").shadowRoot.querySelector(\"#datePicker\")";
		String returnDate="";
		boolean flag= false;
		
		WebElement date=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#coverageStartInput\")");
		WebElement coverageStart=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#coverageStart\")");
		String beforeCoverageStart=coverageStart.getText();
		String currentDateText= date.getAttribute("value");
		WebElement nextButton=(WebElement) js.executeScript("return "+calPath+".shadowRoot.querySelector(\" paper-icon-button:nth-child(3)\").shadowRoot.querySelector(\"#icon\")");
		date.click();
		wait.until(ExpectedConditions.elementToBeClickable(nextButton));
		Thread.sleep(5000);

		WebElement currentDate=(WebElement) js.executeScript("return " + calPath
				+ ".shadowRoot.querySelector(\"div.each-days-of-month.is-today.chosen-days-of-month\")");
		
		for (int i = 1; i < 11; i++) {
			System.out.println("Current Month"+i);
			Long dateCount= (Long) js.executeScript("return " + calPath	+ ".shadowRoot.querySelectorAll(\"div.each-days-of-month[tabindex='0']\").length");
			System.out.println("Current Month No Of Days"+dateCount);
			for (int j = 0; j < dateCount; j++) {
				WebElement dateCell=(WebElement) js.executeScript("return "+calPath+".shadowRoot.querySelectorAll(\"div.each-days-of-month[tabindex='0']\")["+j+"]");
				if(i==1 && !dateCell.equals(currentDate)) {
					if(dateCell.getAttribute("aria-disabled") !=null) {
						returnDate= dateCell.getText();
						System.out.println(returnDate);
						flag=true;
						break;
					}
					continue;
				}else if(i>1 && dateCount<30) {
					WebElement wb=(WebElement) js.executeScript("return "+calPath+".shadowRoot.querySelector(\"div.each-days-of-month[aria-label='"+dateCount+"']\")");
					returnDate= wb.getText();
					System.out.println(returnDate);
					wb.click();
					Thread.sleep(10000);
					wait.until(ExpectedConditions.elementToBeClickable(date));
					flag=true;
					break;
				}
				
			}
			if(!flag) {
				nextButton.click();
				Thread.sleep(5000);
				wait.until(ExpectedConditions.elementToBeClickable(nextButton));
			}else {
				break;
			}
			
		}		
		String selectedDate= date.getAttribute("value");
		System.out.println("Previously Selected Date :"+currentDateText+" & Current Selected Date :"+selectedDate);
		String afterCoverageStart=coverageStart.getText();
		System.out.println("Previous Summary Policy Selected Date :"+beforeCoverageStart+" & Current Summary Policy Selected Date :"+afterCoverageStart);
	}
	
	
	@Given("I change the policy startDate to minimum allowed on date picker")
	public void i_change_the_policy_start_date_to_minimum_allowed_on_date_picker() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String jspath="document.querySelector(\"edi-checkout\").shadowRoot.querySelector(\"div:nth-child(1) > edi-user-details\")";
		String calPath="document.querySelector(\"edi-checkout\").shadowRoot.querySelector(\"div > div.col-12.col-md-8.form-col > div:nth-child(1) > edi-user-details\").shadowRoot.querySelector(\"#coverageStartDatepicker\").shadowRoot.querySelector(\"#datePicker\").shadowRoot.querySelector(\"#datePicker\")";
		String returnDate="";
		boolean flag= false;
		
		WebElement date=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#coverageStartInput\")");
		WebElement coverageStart=(WebElement) js.executeScript("return "+jspath+".shadowRoot.querySelector(\"#coverageStart\")");
		String beforeCoverageStart=coverageStart.getText();
		String currentDateText= date.getAttribute("value");
		WebElement nextButton=(WebElement) js.executeScript("return "+calPath+".shadowRoot.querySelector(\" paper-icon-button:nth-child(1)\").shadowRoot.querySelector(\"#icon\")");
		date.click();
		wait.until(ExpectedConditions.elementToBeClickable(nextButton));
		Thread.sleep(5000);

		WebElement currentDate=(WebElement) js.executeScript("return " + calPath
				+ ".shadowRoot.querySelector(\"div.each-days-of-month.is-today.chosen-days-of-month\")");
		for (int i = 1; i < 11; i++) {
			System.out.println("Current Month"+i);
			Long dateCount= (Long) js.executeScript("return " + calPath	+ ".shadowRoot.querySelectorAll(\"div.each-days-of-month[tabindex='0']\").length");
			System.out.println("Current Month No Of Days"+dateCount);
			for (int j = 0; j < dateCount; j++) {
				WebElement dateCell=(WebElement) js.executeScript("return "+calPath+".shadowRoot.querySelectorAll(\"div.each-days-of-month[tabindex='0']\")["+j+"]");
				if(i==1 && !dateCell.equals(currentDate)) {
					if(dateCell.getAttribute("aria-disabled") !=null) {
						returnDate= dateCell.getText();
						System.out.println(returnDate);
						flag=true;
						break;
					}
					continue;
				}else if(i>1 && dateCount<30) {
					WebElement wb=(WebElement) js.executeScript("return "+calPath+".shadowRoot.querySelectorAll(\"div.each-days-of-month[tabindex='0']\")[0]");
					returnDate= wb.getText();
					System.out.println(returnDate);
					wb.click();
					Thread.sleep(10000);
					wait.until(ExpectedConditions.elementToBeClickable(date));
					flag=true;
					break;
				}
				
			}
			if(!flag) {
				nextButton.click();
				Thread.sleep(5000);
				wait.until(ExpectedConditions.elementToBeClickable(nextButton));
			}else {
				break;
			}
			
		}		
		String selectedDate= date.getAttribute("value");
		System.out.println("Previously Selected Date :"+currentDateText+" & Current Selected Date :"+selectedDate);
		String afterCoverageStart=coverageStart.getText();
		System.out.println("Previous Summary Policy Selected Date :"+beforeCoverageStart+" & Current Summary Policy Selected Date :"+afterCoverageStart);
	}


	@After
	public static void tearDown(Scenario scenario) {
		System.out.println("Execution Completed");
		driver.quit();
	}
}
