package bolttech.runner;




import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.CucumberOptions;




@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/FeatureFiles" }, glue = { "steps" }, tags = "@TestUser", monochrome = true, plugin = {
		"pretty","html:target/cucumber-reports.html"}, publish = true)


public class TestRunner{
	
	
}