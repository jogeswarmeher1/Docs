package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ShadowDomUtils{
	private WebDriver driver;
	public ShadowDomUtils(WebDriver driver) {
		this.driver=driver;
	}
	
	public WebElement getShadowDomElement(String[] shadowHostSelectors, String finalElement) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement wb = null;
		for (String hostSelector : shadowHostSelectors) {
			if (wb == null) {
				wb = (WebElement) js.executeScript("return document.querySelector(argument[0]).shadowRoot",
						hostSelector);
			} else {
				wb = (WebElement) js.executeScript("return argument[0].shadowroot.querySelector(argument[1])", wb,
						hostSelector);
			}
		}
		return wb.findElement(By.cssSelector(finalElement));

	}
}